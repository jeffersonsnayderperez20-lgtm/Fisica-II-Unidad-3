import { useState } from "react";
import appSource from "../App.tsx?raw";
import circuitsSource from "../modules/Circuits.tsx?raw";
import physicsSource from "../physics/circuit.ts?raw";

const files = [
  { path: "src/physics/circuit.ts", source: physicsSource },
  { path: "src/modules/Circuits.tsx", source: circuitsSource },
  { path: "src/App.tsx", source: appSource },
];

export function SourceViewer() {
  const [selected, setSelected] = useState(0);
  const [copied, setCopied] = useState(false);
  const current = files[selected];

  async function copySource() {
    try {
      await navigator.clipboard.writeText(current.source);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  }

  return (
    <details className="source-viewer" id="codigo-fuente">
      <summary>
        <span>
          <b>Código fuente del simulador</b>
          <small>Consulta los archivos principales o descarga el proyecto completo.</small>
        </span>
        <span className="source-summary-action">Ver código</span>
      </summary>
      <div className="source-content">
        <div className="source-toolbar">
          <div className="source-tabs" role="tablist" aria-label="Archivos de código">
            {files.map((file, index) => (
              <button
                key={file.path}
                type="button"
                role="tab"
                aria-selected={selected === index}
                className={selected === index ? "active" : ""}
                onClick={() => setSelected(index)}
              >
                {file.path.split("/").at(-1)}
              </button>
            ))}
          </div>
          <button type="button" onClick={copySource}>
            {copied ? "Copiado" : "Copiar archivo"}
          </button>
        </div>
        <p className="source-path">{current.path}</p>
        <pre className="source-code"><code>{current.source}</code></pre>
        <a className="source-download" href="./codigo-fuente.zip" download>
          Descargar código fuente completo (.zip)
        </a>
      </div>
    </details>
  );
}
