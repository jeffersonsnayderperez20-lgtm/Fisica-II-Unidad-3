# CampoLab · Física II · Unidad 3

Simulador educativo de circuitos resistivos en serie, paralelo y mixtos, con fuente de voltaje, visualizador de Ohm, resultados de Kirchhoff, potencia y estados de circuito abierto y cortocircuito.

## Abrir el simulador

Enlace público del simulador: https://campolab-fisica-ii-unidad-3.lively-stone-5707.chatgpt.site

## Ejecutar localmente

Se requiere Node.js 22.12 o superior. En la carpeta del proyecto, ejecuta:

```bash
npm install
npm run dev
```

Abre la dirección local que muestra la terminal. La aplicación incluye una sección desplegable para consultar archivos clave del código fuente y un enlace para descargar el ZIP completo.

## Archivos principales

- `src/modules/Circuits.tsx`: controles y constructor guiado de circuitos.
- `src/physics/circuit.ts`: cálculo de resistencia equivalente, corrientes, potencia y estados de circuito.
- `src/components/SourceViewer.tsx`: visor de código dentro de la página.
- `src/components/Plot.tsx`: curvas 2D del visualizador de Ohm.
- `src/styles.css`: interfaz adaptable.

Las magnitudes internas se expresan en unidades SI. Los modelos de conductores ideales usan cero ohmios; una rama abierta se representa con resistencia infinita.
