export type Vec = [number, number, number];
export const add = (a: Vec, b: Vec): Vec => [
  a[0] + b[0],
  a[1] + b[1],
  a[2] + b[2],
];
export const sub = (a: Vec, b: Vec): Vec => [
  a[0] - b[0],
  a[1] - b[1],
  a[2] - b[2],
];
export const scale = (a: Vec, s: number): Vec => [a[0] * s, a[1] * s, a[2] * s];
export const dot = (a: Vec, b: Vec) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
export const cross = (a: Vec, b: Vec): Vec => [
  a[1] * b[2] - a[2] * b[1],
  a[2] * b[0] - a[0] * b[2],
  a[0] * b[1] - a[1] * b[0],
];
export const norm = (a: Vec) => Math.hypot(...a);
export const unit = (a: Vec): Vec =>
  norm(a) > 1e-30 ? scale(a, 1 / norm(a)) : [0, 0, 0];
export const finite = (a: Vec) => a.every(Number.isFinite);
export const EPS0 = 8.8541878128e-12;
export const K = 1 / (4 * Math.PI * EPS0);
export const MU0 = 4 * Math.PI * 1e-7; // Aproximación educativa de la permeabilidad del vacío.
export const EXCLUSION = 0.08; // metros, región omitida; no es un radio físico.
