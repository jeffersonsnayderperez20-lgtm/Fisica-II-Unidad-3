import { Circuits } from "./modules/Circuits";
import { SourceViewer } from "./components/SourceViewer";

export default function App() {
  return (
    <>
      <header className="topbar">
        <a className="brand" href="./">
          <span className="brand-mark">⌁</span>
          <b>Campo<span>Lab</span></b>
          <span className="course">Unidad 3</span>
        </a>
        <nav aria-label="Enlaces del proyecto">
          <a href="#simulador">Simulador</a>
          <a href="#codigo-fuente">Código fuente</a>
          <a href="./codigo-fuente.zip" download>Descargar ZIP</a>
        </nav>
      </header>
      <main>
        <div className="hero" id="simulador">
          <div>
            <p className="eyebrow">FÍSICA II · ENTREGA GRUPAL · GRUPO 2</p>
            <h1>Corriente eléctrica y ley de Ohm</h1>
            <p>Unidad 3 · Circuitos resistivos y cálculos en SI</p>
          </div>
        </div>
        <nav className="units" aria-label="Unidad de esta entrega">
          <div className="selected">
            <small>UNIDAD 03</small>
            <b>Circuitos y ley de Ohm</b>
            <em>Conexiones, corriente y potencia</em>
          </div>
        </nav>
        <Circuits />
        <section className="source-section" aria-label="Código fuente">
          <SourceViewer />
        </section>
      </main>
      <footer>
        CampoLab · Física II · Unidad 3 · Docente: Ramiro Manrique Rua
      </footer>
    </>
  );
}
