import { useState } from "react";
import { solveCircuit } from "../physics/circuit";
import { Num, Panel, Metric, fmt } from "../components/Controls";
import { Plot } from "../components/Plot";
const examples: Record<string, number[][]> = {
  Serie: [[100], [200], [300]],
  Paralelo: [[100, 200, 300]],
  Mixto: [[100], [200, 300], [50]],
};
export function Circuits() {
  const [stages, setStages] = useState<number[][]>(examples.Mixto),
    [V, setV] = useState(12),
    [ohmR, setOhmR] = useState(100),
    [ohmV, setOhmV] = useState(12);
  const r = solveCircuit(stages, V),
    update = (i: number, j: number, n: number) =>
      setStages(
        stages.map((s, a) =>
          a === i ? s.map((v, b) => (b === j ? n : v)) : s,
        ),
      );
  const w = Math.max(650, 150 + stages.length * 190);
  return (
    <>
      <div className="module-toolbar">
        <span className="tag">Constructor guiado · corriente continua</span>
        <button
          onClick={() => {
            setStages(examples.Mixto);
            setV(12);
            setOhmR(100);
            setOhmV(12);
          }}
        >
          Restablecer
        </button>
      </div>
      <div className="workspace">
        <Panel title="Construye el circuito" className="parameters">
          <Num
            label="Fuente ideal (V)"
            value={V}
            onChange={setV}
            min={-1000}
            max={1000}
          />
          <div className="preset-row">
            {Object.keys(examples).map((k) => (
              <button key={k} onClick={() => setStages(examples[k])}>
                {k}
              </button>
            ))}
          </div>
          <p>
            Los bloques se conectan en serie. Dentro de cada bloque, las ramas
            están en paralelo.
          </p>
          {stages.map((s, i) => (
            <article className="charge-card" key={i}>
              <div className="charge-title">
                <b>Bloque {i + 1}</b>
                <button
                  disabled={stages.length === 1}
                  aria-label={`Eliminar bloque ${i + 1}`}
                  onClick={() => setStages(stages.filter((_, j) => j !== i))}
                >
                  ×
                </button>
              </div>
              {s.map((v, j) => (
                <div className="branch-editor" key={j}>
                  <label>
                    R{i + 1}.{j + 1}
                    <select
                      aria-label={`Estado R${i + 1}.${j + 1}`}
                      value={
                        v === Infinity ? "open" : v === 0 ? "wire" : "resistor"
                      }
                      onChange={(e) =>
                        update(
                          i,
                          j,
                          e.target.value === "open"
                            ? Infinity
                            : e.target.value === "wire"
                              ? 0
                              : 100,
                        )
                      }
                    >
                      <option value="resistor">Resistencia</option>
                      <option value="open">Abierta</option>
                      <option value="wire">Cable ideal</option>
                    </select>
                  </label>
                  {Number.isFinite(v) && v > 0 && (
                    <Num
                      label={`R${i + 1}.${j + 1} (Ω)`}
                      value={v}
                      min={0.001}
                      max={1e7}
                      onChange={(n) => update(i, j, n)}
                    />
                  )}
                  <button
                    className="text-button"
                    disabled={s.length === 1}
                    onClick={() =>
                      setStages(
                        stages.map((a, b) =>
                          b === i ? a.filter((_, k) => k !== j) : a,
                        ),
                      )
                    }
                  >
                    Eliminar rama {j + 1}
                  </button>
                </div>
              ))}
              <button
                disabled={s.length >= 4}
                onClick={() =>
                  setStages(stages.map((s, j) => (j === i ? [...s, 100] : s)))
                }
              >
                + Rama paralela
              </button>
            </article>
          ))}
          <button
            className="full"
            disabled={stages.length >= 4}
            onClick={() => setStages([...stages, [100]])}
          >
            + Bloque en serie
          </button>
        </Panel>
        <div className="main-column">
          <Panel title="Esquema del circuito">
            <div className="circuit-scroll">
              <svg
                className="circuit"
                viewBox={`0 0 ${w} 380`}
                style={{ minWidth: Math.min(w, 650) }}
                role="img"
                aria-label="Fuente conectada a bloques de resistencias en serie y ramas paralelas"
              >
                <path
                  d={`M60 130 V65 H130 M${130 + stages.length * 190} 65 H${w - 30} V330 H60 V190`}
                  fill="none"
                  stroke="#51727a"
                  strokeWidth="3"
                />
                <circle
                  cx="60"
                  cy="160"
                  r="30"
                  fill="white"
                  stroke="#078677"
                  strokeWidth="3"
                />
                <text x="60" y="153" textAnchor="middle">
                  +
                </text>
                <text x="60" y="180" textAnchor="middle">
                  −
                </text>
                <text x="18" y="222">
                  {V} V
                </text>
                {stages.map((s, i) => {
                  const x = 130 + i * 190;
                  return (
                    <g key={i}>
                      <text
                        x={x + 80}
                        y="30"
                        textAnchor="middle"
                        fontWeight="bold"
                      >
                        Bloque {i + 1}
                      </text>
                      <path
                        d={`M${x} 65 V${65 + (s.length - 1) * 65} M${x + 160} 65 V${65 + (s.length - 1) * 65} M${x + 160} 65 H${x + 190}`}
                        stroke="#51727a"
                        fill="none"
                        strokeWidth="3"
                      />
                      {s.map((v, j) => {
                        const y = 65 + j * 65;
                        return (
                          <g key={j}>
                            <path
                              d={`M${x} ${y} H${x + 45} M${x + 115} ${y} H${x + 160}`}
                              stroke="#51727a"
                              strokeWidth="3"
                            />
                            {v === Infinity ? (
                              <path
                                d={`M${x + 45} ${y} L${x + 98} ${y - 20}`}
                                stroke="#dc714c"
                                strokeWidth="3"
                              />
                            ) : v === 0 ? (
                              <line
                                x1={x + 45}
                                y1={y}
                                x2={x + 115}
                                y2={y}
                                stroke="#51727a"
                                strokeWidth="3"
                              />
                            ) : (
                              <rect
                                x={x + 45}
                                y={y - 12}
                                width="70"
                                height="24"
                                rx="4"
                                fill="#e2f3ef"
                                stroke="#078677"
                                strokeWidth="2"
                              />
                            )}
                            <text
                              x={x + 80}
                              y={y + 31}
                              textAnchor="middle"
                              fontSize="12"
                            >
                              R{i + 1}.{j + 1}:{" "}
                              {v === Infinity ? "abierta" : fmt(v, "Ω")}
                            </text>
                          </g>
                        );
                      })}
                    </g>
                  );
                })}
                <text x={w / 2} y="366" textAnchor="middle" fill="#51727a">
                  Retorno a la fuente · conductores ideales
                </text>
              </svg>
            </div>
          </Panel>
          {r.status === "ok" ? (
            <Panel title="Resultados por rama">
              <div className="table-scroll">
                <table>
                  <thead>
                    <tr>
                      <th>Rama</th>
                      <th>ΔV (V)</th>
                      <th>I (A)</th>
                      <th>P (W)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {r.stages.flatMap((s, i) =>
                      s.branches.map((b, j) => (
                        <tr key={`${i}.${j}`}>
                          <td>
                            R{i + 1}.{j + 1}
                          </td>
                          <td>{fmt(b.V)}</td>
                          <td>{b.I === null ? "Indeterminada" : fmt(b.I)}</td>
                          <td>{b.P === null ? "0 (cable ideal)" : fmt(b.P)}</td>
                        </tr>
                      )),
                    )}
                  </tbody>
                </table>
              </div>
              <p>
                Kirchhoff, lazos: ΣΔV ={" "}
                {fmt(
                  r.stages.reduce((a, b) => a + b.V, 0),
                  "V",
                )}{" "}
                = V de la fuente.
              </p>
              <p>
                Kirchhoff, nodos: la suma de corrientes de cada bloque es I
                total, salvo repartos indeterminados entre cables ideales
                paralelos.
              </p>
            </Panel>
          ) : (
            <p className="error-box" role="alert">
              {r.status === "open"
                ? "Circuito abierto: no existe un camino completo. I total = 0 A. No se asignan voltajes a nodos flotantes."
                : "Cortocircuito ideal: R equivalente = 0 Ω. La fuente ideal no determina una corriente finita; no se presenta un valor numérico engañoso."}
            </p>
          )}
          <Panel title="Laboratorio de la ley de Ohm">
            <div className="two-controls">
              <Num
                label="Resistencia de exploración (Ω)"
                value={ohmR}
                onChange={setOhmR}
                min={1}
                max={10000}
              />
              <Num
                label="Voltaje de exploración (V)"
                value={ohmV}
                onChange={setOhmV}
                min={-24}
                max={24}
              />
            </div>
            <Plot
              data={Array.from({ length: 49 }, (_, i) => ({
                x: i - 24,
                y: (i - 24) / ohmR,
              }))}
              xLabel="V (V)"
              yLabel="I (A)"
              point={{ x: ohmV, y: ohmV / ohmR }}
            />
            <p>
              I = {fmt(ohmV / ohmR, "A")} · pendiente 1/R. Este explorador es
              independiente del circuito superior.
            </p>
          </Panel>
        </div>
        <Panel title="Balance del circuito" className="results">
          <Metric label="Resistencia equivalente" value={r.R} unit="Ω" />
          <Metric label="Corriente total" value={r.I ?? NaN} unit="A" />
          <Metric label="Potencia entregada" value={r.P ?? NaN} unit="W" />
          <div className="formula">
            V = IR
            <br />
            Rserie = Σ Rᵢ
            <br />1 / Rparalelo = Σ 1/Rᵢ
            <br />P = VI = I²R
          </div>
          <p>
            En serie, cada bloque conduce la misma corriente total. En paralelo,
            las ramas comparten la caída de voltaje.
          </p>
          <p>
            Hasta cuatro bloques, cada uno con cuatro ramas. Sin puentes de
            Wheatstone ni redes arbitrarias. Resistencias óhmicas constantes,
            fuente y cables ideales.
          </p>
          <p>
            Una rama abierta tiene resistencia infinita. Un cable tiene
            resistencia cero. Varios cables en paralelo dejan indeterminado el
            reparto de corriente.
          </p>
          <small>
            Los valores negativos de la fuente invierten el sentido de las
            corrientes; la disipación resistiva permanece no negativa.
          </small>
        </Panel>
      </div>
    </>
  );
}
